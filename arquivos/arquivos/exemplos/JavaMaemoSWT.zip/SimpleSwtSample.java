import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class SimpleSwtSample
{
	public static void main(String[] args)
    {
		// pega o display
		Display display = Display.getDefault();
		// cria a janela principal da aplicacao
		final Shell shell = new Shell(display);
		shell.setLayout(new RowLayout(SWT.VERTICAL));
		// cria e adiciona um Label
		Label label = new Label(shell, SWT.CENTER);
		label.setText("Ola Maemo N800!");
		// cria e adiciona um Label
		// com as informacoes do sistema
		Label lblSistema = new Label(shell, SWT.CENTER);
		lblSistema.setText(info());
		// cria e adiciona um Button
		Button button = new Button(shell, SWT.CENTER);
		button.setText("Fechar");
		// adicionar um Listener para fechar a aplicação
		button.addListener(SWT.Selection, new Listener()
        {
			public void handleEvent(Event arg0)
            {
				shell.dispose();
			}
		});
		// abre a janela principal
		shell.open();
		// inicia a interface grafica
		while(!shell.isDisposed())
        {
			if (!display.readAndDispatch())
            {
				display.sleep();
            }
        }
	}

	public static String info()
	{
		String versaoJava = System.getProperty("java.version");
		String nomeSO = System.getProperty("os.name");
		String versaoSO = System.getProperty("os.version");
		return "Versao Java: " + versaoJava + "\nS.O.: " + nomeSO + " " + versaoSO;
	}
}